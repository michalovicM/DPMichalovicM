bl_info = {
    "name": "3D Identifier Addon",
    "author": "Martin Michalovic",
    "version": (5,2),
    "blender": (3, 3, 1),
    "location": "View3D > Tools panel > My Addon",
    "description": "Programaticke generovanie 3D identifikatora - DP",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object",
    "icon": "PLUGIN",
}

import bpy 
import random
import math
import numpy as np
import bmesh
from mathutils import Vector
import os
import mathutils
import time
import sys
import subprocess
from mathutils import Matrix
from math import radians

import bpy
from bpy.props import BoolProperty, IntProperty, FloatProperty, PointerProperty

class MyProperties(bpy.types.PropertyGroup):
    
    identifier_ID: bpy.props.StringProperty(name="Enter ID", default="0")
    change_other_values: bpy.props.BoolProperty(name="Change Other Values")
    change_b_e_values: bpy.props.BoolProperty(name="Change Basic Element Values")
    identifier_size: bpy.props.IntProperty(name="Identifier size: ", default=5, min=3)
    basic_element_size: bpy.props.FloatProperty(name="Basic element size: ", default=0.15, min=0, max=100)
    numberOF_basic_element: bpy.props.IntProperty(name="Enter number of basic e.:", default=3, min=3)
    
    def reset_id(self, context):
        self.identifier_ID = "0"
        
    def reset_b_e_val(self, context):
        self.basic_element_size = 0.15
        self.numberOF_basic_element = 3
        
    def reset_other(self, context):
        self.identifier_size = 5
    
class VIEW3D_PT_my_addon(bpy.types.Panel):
    bl_label = "3D Identifier"
    bl_idname = "VIEW3D_PT_my_addon"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Create Identifier"

    def draw(self, context):
        layout = self.layout
        props = context.scene.my_tool

        layout.prop(props, "identifier_ID")
        layout.prop(props, "change_other_values")
        layout.prop(props, "change_b_e_values")

        if props.change_b_e_values:
            box = layout.box()
            box.prop(props, "basic_element_size")
            box.prop(props, "numberOF_basic_element")

        if props.change_other_values:
            box = layout.box()
            box.prop(props, "identifier_size")

        layout.separator()

        layout.operator("my.operator")

class MYADDON_OT_my_operator(bpy.types.Operator):
    bl_idname = "my.operator"
    bl_label = "Generate Identifier"
    
    def execute(self, context):
        
        props = context.scene.my_tool
        
        if not props.change_b_e_values:
            props.reset_b_e_val(context)
        if not props.change_other_values:
            props.reset_other(context)
        
        try:
            identifier_ID = int(props.identifier_ID)
        except ValueError:
            self.report({'ERROR'}, "INCORECT INPUT!")
            return {'CANCELLED'}
            
        if int(props.identifier_ID) > 0:
        
            self.clean_scene()
            
            identifier_ID = int(props.identifier_ID)
            size = props.identifier_size
            basic_element_size = props.basic_element_size
            numberOF_basic_element = props.numberOF_basic_element
            quaternary_num1 = ''
            
            list = [[0 for _ in range(size+2)] for _ in range(size+2)]

            # fill in the first and last row with 0
            for j in range(size+2):
                list[0][j] = 0
                list[size+1][j] = 0

            while identifier_ID > 0:
                remainder = int(identifier_ID % 4)
                quaternary_num1 = str(remainder) + quaternary_num1
                identifier_ID //= 4
            quaternary_num_len = len(quaternary_num1)

            substrings = [quaternary_num1[i:i+size] for i in range(0, len(quaternary_num1), size)]

            decimal_numbers = [int(digit, 4) for substring in substrings for digit in substring]
            index = 0
            for i in range(1, size+1):
                list[i][0] = 0
                list[i][size+1] = 0

                for j in range(1, size+1):
                    if index < len(decimal_numbers):
                        list[i][j] = decimal_numbers[index]
                        index += 1
                    else:
                        list[i][j] = 0
            if index < len(quaternary_num1):
                self.report({'INFO'}, "WARNING: String was shortened!")
            else:
                self.report({'INFO'}, "Conversion of ID SUCCESSFUL!")
            
            self.createCube(context, list, size, numberOF_basic_element, basic_element_size)
            props.reset_id(context)
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Input must be greater than 0!")
            return {'CANCELLED'}
             
    def clean_scene(self):
        if bpy.context.active_object and bpy.context.active_object.mode == "EDIT":
            bpy.ops.object.editmode_toggle()
        for obj in bpy.data.objects:
            obj.hide_set(False)
            obj.hide_select = False
            obj.hide_viewport = False
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete()

        collection_names = [col.name for col in bpy.data.collections]
        for name in collection_names:
            bpy.data.collections.remove(bpy.data.collections[name])

        # in the case when you modify the world shader
        world_names = [col.name for col in bpy.data.worlds]
        for name in world_names:
            bpy.data.worlds.remove(bpy.data.worlds[name])
        # create a new world data block
        bpy.ops.world.new()
        bpy.context.scene.world = bpy.data.worlds["World"]

        self.purge_orphans()
            
    def purge_orphans(self):
        if bpy.app.version >= (3, 0, 0):
            bpy.ops.outliner.orphans_purge(
                 do_local_ids=True, do_linked_ids=True, do_recursive=True
             )
        else:
            result = bpy.ops.outliner.orphans_purge()
            if result.pop() != "CANCELLED":
                 self.purge_orphans()
         
    def create_prop(self, context, size, STLedge):
        
        bpy.ops.mesh.primitive_cube_add()
        bpy.context.object.location = (size*STLedge-1, size*STLedge-1, (size*STLedge-2)*2)
        bpy.context.object.scale = (size*STLedge-2, size*STLedge-2, 1)

        obj = bpy.context.active_object
        mesh = obj.data
        
        vertex_idx = 7
        vertex = mesh.vertices[vertex_idx]
        vertex.select = True

        move_distance = (size*STLedge)*1.3
        vertex.co[2] += move_distance
        mesh.update()

        obj = bpy.context.selected_objects[0]
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)

        obj.rotation_mode = 'XYZ'
        obj.rotation_euler[0] += 3.14159
        
        
    def createCube(self, context, list, size, STLedge, width):
         
        #edge - dĺžka objektu vypočítaná ako veľkosť jednej kocky * ich počet
        edge = 2*STLedge
        
        #move - posunutie objektu s ohľadom na šetrenie pri tlači - vždy o jednu kocku menej (-2)
        move = edge-2
        
        locations = []
        print("LOCATIONS:", locations)
        
        size = len(list[0])
        
        # získanie cesty k priečinku models v rámci add-onu
        models_dir = os.path.join(os.path.dirname(__file__), "models")

        # zoznam názvov modelov, ktoré chceme importovať
        model_names = ["element0.stl","element1.stl","element2.stl","element3.stl","element4.stl"]
                
    #zadná stena
        val = size-1
        for x in range(size):
            for y in range(size):
                for z in range(size):                              
                    if(x in range(size) and y == (size-1) and z in range(size)):
                        if(val < 0):
                            val = size-1
                        if(list[x][z] == 0):
                            new_location = (edge*val+move, edge*y+move+width, edge*x)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                

                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -3.14159

                                # Move the object to a new location
                                obj.location = new_location
                                    

                        elif(list[x][z] == 0):
                            new_location = ((edge*val)+move, edge*y+move+width, edge*x)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                               
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -3.14159

                                # Move the object to a new location
                                obj.location = new_location
                                
                        
                        elif(list[x][z] == 1):
                            new_location = ((edge*val)+move, edge*y+move+width, edge*x)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element2.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -3.14159
                            

                                # Move the object to a new location
                                obj.location = new_location
                                
                        
                        elif(list[x][z] == 2):
                            new_location = ((edge*val)+move, edge*y+move+width, edge*x)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element3.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -3.14159
                                
                                # Move the object to a new location
                                obj.location = new_location
                                
                        elif(list[x][z] == 3):
                            new_location = ((edge*val)+move, edge*y+move+width, edge*x)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element4.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -3.14159

                                # Move the object to a new location
                                obj.location = new_location
     
        #pravá stena
        for x in range(size):
            for y in range(size):
                for z in range(size):                                       
                    if(x==(size-1) and y in range(size) and z in range(size)):
                        if(list[z][y] == 0):
                            new_location = (edge*x+move+width, edge*y, edge*z)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += 1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        
                                
                        elif(list[z][y] == 0):
                            new_location = (edge*x+move+width, edge*y, edge*z)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += 1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        
                        elif(list[z][y] == 1):
                            new_location = (edge*x+move+width, edge*y, edge*z)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element2.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += 1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        
                        elif(list[z][y] == 2):
                            new_location = (edge*x+move+width, edge*y, edge*z)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element3.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += 1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                            
                        elif(list[z][y] == 3):
                            new_location = (edge*x+move+width, edge*y, edge*z)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element4.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += 1.5708

                                # Move the object to a new location
                                obj.location = new_location
        
    #predná stena
        print("PREDNA STENA")
        for x in range(size):
            for y in range(size):
                for z in range(size):                                                          
                    if(x in range(size) and y == 0 and z in range(size)):
                        if(list[x][z] == 0):
                            new_location = (edge*z, edge*y-width, edge*x)
                            print("LOCATION:", new_location)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Move the object to a new location
                                obj.location = new_location
                                     
                        elif(list[x][z] == 0):
                            new_location = (edge*z, edge*y-width, edge*x)
                            print("LOCATION:", new_location)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Move the object to a new location
                                obj.location = new_location
      
                        elif(list[x][z] == 1):
                            new_location = (edge*z, edge*y-width, edge*x)
                            print("LOCATION:", new_location)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element2.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Move the object to a new location
                                obj.location = new_location
                        
                        elif(list[x][z] == 2):
                            new_location = (edge*z, edge*y-width, edge*x)
                            print("LOCATION:", new_location)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element3.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Move the object to a new location
                                obj.location = new_location
                        elif(list[x][z] == 3):
                            new_location = (edge*z, edge*y-width, edge*x)
                            print("LOCATION:", new_location)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element4.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)

                                # Move the object to a new location
                                obj.location = new_location 
                                                                            
        #ľavá stena 
        val = size-1                 
        for x in range(size):
            for y in range(size):
                for z in range(size):                                                               
                    if(x==0 and y in range(size) and z in range(size)):
                        if(val < 0):
                            val = size-1
                        if(list[y][z] == 0):
                            new_location = (edge*x-width, edge*val+move, edge*y)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                 # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                        elif(list[y][z] == 0):
                            new_location = (edge*x-width, edge*val+move, edge*y)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                 # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        
                        elif(list[y][z] == 1):
                            new_location = (edge*x-width, edge*val+move, edge*y)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element2.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                 # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        
                        elif(list[y][z] == 2):
                            new_location = (edge*x-width, edge*val+move, edge*y)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element3.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                 # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                        elif(list[y][z] == 3):
                            new_location = (edge*x-width, edge*val+move, edge*y)
                            val = val-1
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element4.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                
                                 # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'
                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[2] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
        #vrchná stena            
        for x in range(size):
            for y in range(size):
                for z in range(size):                                
                    if(x in range(size) and y in range(size) and z == (size-1)):
                        
                        if(list[y][x] == 0):
                            new_location = (edge*x, edge*y, edge*z+move+width)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element0.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the object's pivot point to the scene's origin
                                bpy.context.scene.cursor.location = (0, 0, 0)
                                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'

                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[0] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                        
                        elif(list[y][x] == 0):
                            new_location = (edge*x, edge*y, edge*z+move+width)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element1.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the object's pivot point to the scene's origin
                                bpy.context.scene.cursor.location = (0, 0, 0)
                                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'

                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[0] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                        
                        elif(list[y][x] == 1):
                            new_location = (edge*x, edge*y, edge*z+move+width)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element2.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the object's pivot point to the scene's origin
                                bpy.context.scene.cursor.location = (0, 0, 0)
                                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'

                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[0] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                        
                        elif(list[y][x] == 2):
                            new_location = (edge*x, edge*y, edge*z+move+width)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element3.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the object's pivot point to the scene's origin
                                bpy.context.scene.cursor.location = (0, 0, 0)
                                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'

                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[0] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location
                                
                        elif(list[y][x] == 3):
                            new_location = (edge*x, edge*y, edge*z+move+width)
                            if(new_location not in locations):
                                locations.append(new_location)
                                filepath = os.path.join(models_dir, "element4.stl")
                                bpy.ops.import_mesh.stl(filepath=filepath)
                                
                                # Select the imported object
                                obj = bpy.context.selected_objects[0]
                                bpy.context.view_layer.objects.active = obj
                                obj.select_set(True)
                                    
                                # set the object's pivot point to the scene's origin
                                bpy.context.scene.cursor.location = (0, 0, 0)
                                bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

                                # set the rotation mode to Euler
                                obj.rotation_mode = 'XYZ'

                                # rotate the object by 90 degrees around the Z axis
                                obj.rotation_euler[0] += -1.5708

                                # Move the object to a new location
                                obj.location = new_location 

    #spodná stena                          
        bpy.ops.mesh.primitive_cube_add(size=2, enter_editmode=False, align='WORLD', location=(size*STLedge-1, size*STLedge-1, -0.7), scale=(size*STLedge, size*STLedge, 1))
        cube = bpy.context.object  
        
    #podpera    
        self.create_prop(context, size, STLedge)

#Skript pre exportovanie Identifikátora
def exportSTL():
    
    bpy.ops.object.select_all(action='SELECT')
    filepath = bpy.path.abspath('//') + bpy.context.scene.name + '.stl'
    bpy.ops.export_mesh.stl(filepath=filepath, check_existing=False, use_selection=True)
    bpy.ops.object.select_all(action='DESELECT')
    
    # Upozornenie o úspešnom exportovaní
    message = "Model was successfully exported to file. " + bpy.context.scene.name + ".stl"
    title = "Export STL"   
    if sys.platform == 'darwin': # macOS
        subprocess.Popen(['osascript', '-e', 'display notification "{}" with title "{}"'.format(message, title)])
    elif sys.platform == 'win32': # Windows
        subprocess.Popen(['powershell', '-Command', 'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show("{}","{}")'.format(message, title)])
    else:
        self.report({'INFO'}, "Model was successfully exported to file.")
  
  
class ExportPanel(bpy.types.Panel):
    bl_label = "Export Panel"
    bl_idname = "OBJECT_PT_export_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Export to .STL"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator("export.stl", text="Export STL")
        row = layout.row()
        row.prop(context.scene, "name", text="File Name")
        row = layout.row()
        row.operator("script.export", text="Export with Script")
        
class ExportWithScript(bpy.types.Operator):
    bl_idname = "script.export"
    bl_label = "Export to .STL"

    def execute(self, context):
        exportSTL()
        return {'FINISHED'}
    
classes = (MyProperties, VIEW3D_PT_my_addon, MYADDON_OT_my_operator, ExportPanel,ExportWithScript)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type=MyProperties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.my_tool

if __name__ == "__main__":
    register()
